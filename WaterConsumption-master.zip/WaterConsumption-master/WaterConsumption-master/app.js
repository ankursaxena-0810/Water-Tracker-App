const express = require("express")
const app = express() 
const mongoose = require('mongoose')
const url = "mongodb+srv://USERNAME:PASSWORD@cluster0.ltblj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"

mongoose.connect(url).then(()=>console.log("Connected to DB"))
app.use(express.json())
app.post("/add-new-post",async(req,res)=>{
    const stdname = req.body.name;
    const stdliters = req.body.liters;
    const stddate =  req.body.date;

    try
    {
        const newstd= new Schema(
            {
                name:stdname,
                liters:stdliters,
                date:stddate,
            }
        )
        const savedStd= await newstd.save()
        res.json(
        {"message" : "Details are saved","data": savedStd}
        )
    }catch(err){
        res.json(err);
    }
})

app.use("/",(req,res)=>{
    res.json(
        {"message" : "Express Server Started"}
    )
})



app.listen(3000,()=>console.log("Express server started"))